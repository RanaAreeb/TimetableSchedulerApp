package com.example.timeatbleschedulerapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class TimetableSchedulerApplication : Application()
