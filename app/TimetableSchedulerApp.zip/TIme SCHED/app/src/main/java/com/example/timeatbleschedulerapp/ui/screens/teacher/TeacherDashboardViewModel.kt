package com.example.timeatbleschedulerapp.ui.screens.teacher

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class TeacherDashboardViewModel @Inject constructor() : ViewModel() {
    // Teacher dashboard logic
}
