package com.example.timeatbleschedulerapp.ui.screens.teacher

import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.timeatbleschedulerapp.R

class ClassListActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_class_list)
    }
}
