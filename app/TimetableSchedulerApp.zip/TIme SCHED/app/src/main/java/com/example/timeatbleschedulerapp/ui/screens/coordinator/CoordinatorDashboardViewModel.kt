package com.example.timeatbleschedulerapp.ui.screens.coordinator

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class CoordinatorDashboardViewModel @Inject constructor() : ViewModel() {
    // Coordinator dashboard logic
}
