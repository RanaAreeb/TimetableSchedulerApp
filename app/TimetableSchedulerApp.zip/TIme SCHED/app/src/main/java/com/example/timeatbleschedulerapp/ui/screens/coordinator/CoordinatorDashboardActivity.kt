package com.example.timeatbleschedulerapp.ui.screens.coordinator

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import com.example.timeatbleschedulerapp.databinding.ActivityDashboardCoordinatorBinding
import com.example.timeatbleschedulerapp.ui.screens.notifications.NotificationsActivity
import com.example.timeatbleschedulerapp.ui.screens.timetable.TimetableViewerActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CoordinatorDashboardActivity : ComponentActivity() {
    
    private lateinit var binding: ActivityDashboardCoordinatorBinding
    private val viewModel: CoordinatorDashboardViewModel by viewModels()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardCoordinatorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupClickListeners()
        observeData()
    }
    
    private fun setupClickListeners() {
        binding.cardGenerateTimetable.setOnClickListener {
            startActivity(Intent(this, GenerateTimetableActivity::class.java))
        }
        
        binding.cardAssignTimetable.setOnClickListener {
            startActivity(Intent(this, AssignTimetableActivity::class.java))
        }
        
        binding.cardManageNotifications.setOnClickListener {
            startActivity(Intent(this, NotificationsActivity::class.java))
        }
        
        binding.cardViewReports.setOnClickListener {
            startActivity(Intent(this, ReportsActivity::class.java))
        }
        
        binding.fabQuickAction.setOnClickListener {
            // Show quick action menu
        }
    }
    
    private fun observeData() {
        // Observe ViewModel data and update UI
    }
}
