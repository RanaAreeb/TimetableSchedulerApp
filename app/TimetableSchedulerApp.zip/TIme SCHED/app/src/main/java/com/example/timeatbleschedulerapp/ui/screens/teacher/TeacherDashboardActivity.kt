package com.example.timeatbleschedulerapp.ui.screens.teacher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import com.example.timeatbleschedulerapp.databinding.ActivityDashboardTeacherBinding
import com.example.timeatbleschedulerapp.ui.screens.notifications.NotificationsActivity
import com.example.timeatbleschedulerapp.ui.screens.timetable.TimetableViewerActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TeacherDashboardActivity : ComponentActivity() {
    
    private lateinit var binding: ActivityDashboardTeacherBinding
    private val viewModel: TeacherDashboardViewModel by viewModels()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardTeacherBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupClickListeners()
        observeData()
    }
    
    private fun setupClickListeners() {
        binding.cardSendNotification.setOnClickListener {
            startActivity(Intent(this, SendNotificationActivity::class.java))
        }
        
        binding.cardViewTimetable.setOnClickListener {
            startActivity(Intent(this, TimetableViewerActivity::class.java))
        }
        
        binding.cardClassList.setOnClickListener {
            startActivity(Intent(this, ClassListActivity::class.java))
        }
    }
    
    private fun observeData() {
        // Observe ViewModel data and update UI
    }
}
