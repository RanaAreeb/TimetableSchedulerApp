package com.example.timeatbleschedulerapp.utils

import android.util.Log
import com.example.timeatbleschedulerapp.data.models.Notification
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

object NotificationTestHelper {
    private const val TAG = "NotificationTestHelper"

    suspend fun createTestNotification(recipientId: String): Boolean {
        return try {
            val firestore = FirebaseFirestore.getInstance()

            val testNotification = Notification(
                id = firestore.collection("notifications").document().id,
                title = "Test Notification",
                message = "This is a test notification to verify the system is working.",
                senderId = "test_sender",
                senderName = "Test Teacher",
                recipientIds = listOf(recipientId),
                timestamp = System.currentTimeMillis(),
                isRead = false
            )

            firestore.collection("notifications")
                .document(testNotification.id)
                .set(testNotification)
                .await()

            Log.d(TAG, "Test notification created successfully")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating test notification", e)
            false
        }
    }
}
