package com.example.timeatbleschedulerapp.ui.screens.student

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import com.example.timeatbleschedulerapp.databinding.ActivityDashboardStudentBinding
import com.example.timeatbleschedulerapp.ui.screens.notifications.NotificationsActivity
import com.example.timeatbleschedulerapp.ui.screens.timetable.TimetableViewerActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class StudentDashboardActivity : ComponentActivity() {
    
    private lateinit var binding: ActivityDashboardStudentBinding
    private val viewModel: StudentDashboardViewModel by viewModels()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardStudentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupClickListeners()
        observeData()
    }
    
    private fun setupClickListeners() {
        binding.cardViewTimetable.setOnClickListener {
            startActivity(Intent(this, TimetableViewerActivity::class.java))
        }
        
        binding.cardNotifications.setOnClickListener {
            startActivity(Intent(this, NotificationsActivity::class.java))
        }
        
        binding.cardContactTeacher.setOnClickListener {
            startActivity(Intent(this, ContactTeacherActivity::class.java))
        }
    }
    
    private fun observeData() {
        // Observe ViewModel data and update UI
    }
}
