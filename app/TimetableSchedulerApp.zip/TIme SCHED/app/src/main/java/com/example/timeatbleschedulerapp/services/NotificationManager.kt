package com.example.timeatbleschedulerapp.services

import android.util.Log
import com.example.timeatbleschedulerapp.data.repository.FCMRepository
import com.example.timeatbleschedulerapp.data.repository.NotificationRepository
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val TAG = "NotificationManager"
private const val FCM_SERVER_KEY = "BMiHkHANiGlYG3f2rQtb139RKpAyNrSeQIYdvDLIWNG5pc5c0koKI83mnv97UD_FIK5u8FVQspq3r-OPoL_95D8" // You'll need to get this from Firebase Console

@Singleton
class NotificationManager @Inject constructor(
    private val notificationRepository: NotificationRepository,
    private val fcmRepository: FCMRepository
) {

    suspend fun sendCompleteNotification(
        title: String,
        message: String,
        senderId: String,
        senderName: String,
        recipientIds: List<String>
    ): Result<String> {
        return try {
            // Step 1: Store notification in Firestore
            val storeResult = notificationRepository.sendNotification(
                title, message, senderId, senderName, recipientIds
            )

            if (storeResult.isFailure) {
                return Result.failure(storeResult.exceptionOrNull() ?: Exception("Failed to store notification"))
            }

            // Step 2: Get FCM tokens for recipients
            val tokensResult = fcmRepository.getFCMTokensForUsers(recipientIds)
            if (tokensResult.isFailure) {
                Log.w(TAG, "Failed to get FCM tokens, notification stored but no push sent")
                return storeResult // Return success for storage even if FCM fails
            }

            val tokens = tokensResult.getOrThrow()
            if (tokens.isEmpty()) {
                Log.w(TAG, "No FCM tokens found for recipients")
                return storeResult
            }

            // Step 3: Send FCM push notifications
            sendFCMNotifications(tokens, title, message)

            Log.d(TAG, "Complete notification sent successfully")
            storeResult

        } catch (e: Exception) {
            Log.e(TAG, "Error sending complete notification", e)
            Result.failure(e)
        }
    }

    private suspend fun sendFCMNotifications(tokens: List<String>, title: String, message: String) {
        withContext(Dispatchers.IO) {
            try {
                // For demonstration, we'll send to each token individually
                // In production, you'd use Firebase Admin SDK or batch sending
                tokens.forEach { token ->
                    sendFCMToToken(token, title, message)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error sending FCM notifications", e)
            }
        }
    }

    private suspend fun sendFCMToToken(token: String, title: String, message: String) {
        try {
            val url = URL("https://fcm.googleapis.com/fcm/send")
            val connection = url.openConnection() as HttpURLConnection

            connection.requestMethod = "POST"
            connection.setRequestProperty("Authorization", "key=$FCM_SERVER_KEY")
            connection.setRequestProperty("Content-Type", "application/json")
            connection.doOutput = true

            val payload = JSONObject().apply {
                put("to", token)
                put("notification", JSONObject().apply {
                    put("title", title)
                    put("body", message)
                    put("icon", "ic_notifications")
                    put("sound", "default")
                })
                put("data", JSONObject().apply {
                    put("title", title)
                    put("body", message)
                    put("type", "timetable_notification")
                })
            }

            val writer = OutputStreamWriter(connection.outputStream)
            writer.write(payload.toString())
            writer.flush()
            writer.close()

            val responseCode = connection.responseCode
            Log.d(TAG, "FCM response code: $responseCode for token: ${token.take(10)}...")

        } catch (e: Exception) {
            Log.e(TAG, "Error sending FCM to token", e)
        }
    }
}
