package com.example.timeatbleschedulerapp.ui.screens.timetable

import android.os.Bundle
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.timeatbleschedulerapp.databinding.ActivityTimetableViewerBinding
import com.google.android.material.tabs.TabLayoutMediator
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TimetableViewerActivity : FragmentActivity() {

    private lateinit var binding: ActivityTimetableViewerBinding
    private val viewModel: TimetableViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTimetableViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupViewPager()
        setupClickListeners()
    }

    private fun setupToolbar() {
        binding.toolbar.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupViewPager() {
        val adapter = DaysPagerAdapter(this)
        binding.viewPagerDays.adapter = adapter

        TabLayoutMediator(binding.tabLayoutDays, binding.viewPagerDays) { tab, position ->
            tab.text = when (position) {
                0 -> "Mon"
                1 -> "Tue"
                2 -> "Wed"
                3 -> "Thu"
                4 -> "Fri"
                5 -> "Sat"
                else -> ""
            }
        }.attach()
    }

    private fun setupClickListeners() {
        binding.btnPreviousWeek.setOnClickListener {
            // Navigate to previous week
        }

        binding.btnNextWeek.setOnClickListener {
            // Navigate to next week
        }
    }

    private class DaysPagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {
        override fun getItemCount(): Int = 6 // Monday to Saturday

        override fun createFragment(position: Int): Fragment {
            return DayTimetableFragment.newInstance(position)
        }
    }
}
